"""
MetaNode SDK - Next-generation Blockchain Infrastructure

A complete console-based SDK for building, deploying, and interacting with 
MetaNode's blockchain-grade federated computing system.
"""

__version__ = "1.0.0-beta"
