"""
MetaNode Cloud Module

Provides blockchain-grade cloud deployment capabilities for MetaNode infrastructure
"""

__version__ = "1.0.0-beta"
