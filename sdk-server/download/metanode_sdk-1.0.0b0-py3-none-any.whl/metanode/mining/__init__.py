"""
MetaNode Mining Module

Provides blockchain-grade mining capabilities for the MetaNode infrastructure
"""

__version__ = "1.0.0-beta"
