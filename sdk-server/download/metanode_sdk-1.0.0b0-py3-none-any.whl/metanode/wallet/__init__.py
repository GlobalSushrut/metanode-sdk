"""
MetaNode Wallet Module

Provides blockchain-grade secure wallet capabilities for the MetaNode infrastructure
"""

__version__ = "1.0.0-beta"
